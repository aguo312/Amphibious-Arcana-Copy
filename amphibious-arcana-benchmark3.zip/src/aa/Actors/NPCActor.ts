import AnimatedSprite from "../../Wolfie2D/Nodes/Sprites/AnimatedSprite";

export default class NPCActor extends AnimatedSprite {

}