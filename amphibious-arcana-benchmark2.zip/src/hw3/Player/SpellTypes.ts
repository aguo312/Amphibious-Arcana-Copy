export const SpellTypes = {
    TONGUE: "TONGUE",
    FIREBALL: "FIREBALL",
    ICE: "ICE"
} as const;
